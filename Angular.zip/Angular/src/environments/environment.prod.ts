export const environment = {
  production: true,
  ApiUrl: 'http://localhost:8090/api/v1.0/tweets',
};
